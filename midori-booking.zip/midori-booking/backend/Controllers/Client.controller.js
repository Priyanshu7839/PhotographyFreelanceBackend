import { supabase } from "../supabase.js";
import bcrypt from "bcryptjs";
import crypto from "crypto";

import { GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { r2 } from "../r2client.js";

import axios from "axios";

export const createClient = async (req, res) => {
  try {
    const {
      clientName,
      eventType,
      workflow_template_id,
      workflowSteps,
      teamAssignments,
      eventDate,
      eventEndDate,
      selectedLocation,
    } = req.body;

    if (
      !clientName ||
      !eventType ||
      !workflowSteps?.length
    ) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      });
    }


    
    const temporaryPassword = crypto.randomBytes(9).toString("base64url");

    // create client
    const {
      data: clientData,
      error: clientError,
    } = await supabase
      .from("clients")
      .insert([
        {
          client_name: clientName,

          event_name: eventType,

          email: `${clientName
            .trim()
            .toLowerCase()
            .replace(
              /\s+/g,
              ""
            )}${Date.now()
            .toString()
            .slice(
              -4
            )}@midori.com`,

          password: await bcrypt.hash(temporaryPassword, 12),

          event_date: eventDate || null,
          event_end_date: eventEndDate || null,
          event_location: selectedLocation || null,


          workflow_template_id:
            workflow_template_id ||
            null,

          created_by:
            req.user.member_id,
        },
      ])
      .select()
      .single();

    if (clientError) {
      return res.status(500).json({
        success: false,
        message:
          clientError.message,
      });
    }

    let projectSteps = [];

    // TEMPLATE WORKFLOW
    if (workflow_template_id) {
      const {
        data: workflowStepsFromDB,
        error: workflowError,
      } = await supabase
        .from("workflow_steps")
        .select("*")
        .eq(
          "workflow_template_id",
          workflow_template_id
        )
        .order("step_order", {
          ascending: true,
        });

      if (workflowError) {
        return res.status(500).json({
          success: false,
          message:
            workflowError.message,
        });
      }

      projectSteps =
        workflowStepsFromDB.map(
          (step) => {
           const assignedStep =
  teamAssignments?.find(
    (assignment) =>
      assignment.workflow_step_id ===
      step.workflow_step_id
  );

return {
  client_id: clientData.client_id,

  workflow_step_id:
    step.workflow_step_id,

  assigned_member_ids:
    assignedStep?.assigned_member_ids || [],

  step_date:
    assignedStep?.step_date || null,

  step_time:
    assignedStep?.step_time || null,

  venue:
    assignedStep?.venue || null,

  step_name:
    step.step_name,

  step_order:
    step.step_order,

  step_status:
    "pending",
};
          }
        );
    }

    // CUSTOM WORKFLOW
    else {
      projectSteps =
        workflowSteps.map(
          (step, index) => {
          const assignedStep =
  teamAssignments?.find(
    (assignment) =>
      assignment.workflow_step_id ===
      step.workflow_step_id
  );

return {
  client_id:
    clientData.client_id,

  workflow_step_id:
    null,

  assigned_member_ids:
    assignedStep?.assigned_member_ids || [],

  step_date:
    assignedStep?.step_date || null,

  step_time:
    assignedStep?.step_time || null,

  venue:
    assignedStep?.venue || null,

  step_name:
    step.step_name,

  step_order:
    step.step_order ||
    index + 1,

  step_status:
    "pending",
};
          }
        );
    }

    const {
      error: projectStepsError,
    } = await supabase
      .from("project_steps")
      .insert(projectSteps);

    if (projectStepsError) {
      return res.status(500).json({
        success: false,
        message:
          projectStepsError.message,
      });
    }

   // create default moodboard
const {
  error: moodboardError,
} = await supabase
  .from("moodboards")
  .insert([
    {
      client_id: clientData.client_id,
    },
  ]);

if (moodboardError) {
  return res.status(500).json({
    success: false,
    message: moodboardError.message,
  });
}

// ----------------------------------------------------
// CREATE DEFAULT INVOICE
// ----------------------------------------------------

const {
  data: invoiceData,
  error: invoiceError,
} = await supabase
  .from("invoices")
  .insert([
    {
      client_id: clientData.client_id,

      invoice_number: `INV-${Date.now()}`,

      invoice_status: "pending",

      subtotal_amount: 0,

      tax_amount: 0,

      discount_amount: 0,

      travel_fee: 0,

      final_amount: 0,

      amount_paid: 0,

      amount_due: 0,

      payment_method: null,

      issue_date: new Date().toISOString().split("T")[0],

      due_date: new Date().toISOString().split("T")[0],

      notes: null,
    },
  ])
  .select()
  .single();

if (invoiceError) {
  return res.status(500).json({
    success: false,
    message: invoiceError.message,
  });
}

// ----------------------------------------------------
// CREATE DEFAULT INVOICE ITEM
// ----------------------------------------------------

const {
  error: invoiceItemError,
} = await supabase
  .from("invoice_items")
  .insert([
    {
      invoice_id: invoiceData.invoice_id,

      item_name: "Photography Package",

      quantity: 1,

      rate: 0,

      amount: 0,
    },
  ]);

if (invoiceItemError) {
  return res.status(500).json({
    success: false,
    message: invoiceItemError.message,
  });
}

    return res.status(201).json({
      success: true,
      message:
        "Client created successfully",
      data: {
        ...clientData,
        // This is the only creation response that contains the generated
        // secret. It is never persisted or returned by client-read endpoints.
        temporary_password: temporaryPassword,
      },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message:
        error.message,
    });
  }
};

export const getWorkflowTemplates = async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("workflow_templates")
      .select("*")
      .eq("is_active", true)
      .order("workflow_template_id");

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};


export const getWorkflowSteps = async (req, res) => {
  try {
    const { templateId } = req.params;

    const { data, error } = await supabase
      .from("workflow_steps")
      .select("*")
      .eq(
        "workflow_template_id",
        templateId
      )
      .order("step_order", {
        ascending: true,
      });

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};



export const getTeamMembers = async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("members")
      .select(
        "member_id, full_name, role"
      )
      .in("role", ["team", "admin"]);

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getAllClients = async (req, res) => {
  try {
    let clients = [];

    // =========================
    // CLIENT LOGIN
    // =========================
    if (
      req.user.user_type ===
      "client"
    ) {
      const {
        data,
        error,
      } = await supabase
        .from("clients")
        .select("*")
        .eq(
          "client_id",
          req.user.client_id
        );

      if (error) throw error;

      clients = data;
    }

    
    // =========================
    // ADMIN / SUPERADMIN
    // =========================
    else if (
      req.user.role === "admin" ||
      req.user.role ===
        "superadmin"
    ) {
      const {
        data,
        error,
      } = await supabase
        .from("clients")
        .select("*")
        .order("created_at", {
          ascending: false,
        });

      if (error) throw error;

      clients = data;
    }

    // =========================
    // TEAM MEMBER
    // =========================
    else {
      const {
  data: assignedSteps,
  error: assignedError,
} = await supabase
  .from("project_steps")
  .select("client_id")
  .contains(
    "assigned_member_ids",
    [req.user.member_id]
  );
      if (assignedError)
        throw assignedError;

      const clientIds = [
        ...new Set(
          assignedSteps.map(
            (step) =>
              step.client_id
          )
        ),
      ];

      if (
        clientIds.length === 0
      ) {
        return res.status(200).json({
          success: true,
          data: [],
        });
      }

      const {
        data,
        error,
      } = await supabase
        .from("clients")
        .select("*")
        .in(
          "client_id",
          clientIds
        )
        .order("created_at", {
          ascending: false,
        });

      if (error) throw error;

      clients = data;
    }

    const dashboardData =
      await Promise.all(
        clients.map(
          async (client) => {
            const {
              data: projectSteps,
              error: stepsError,
            } = await supabase
              .from(
                "project_steps"
              )
              .select("*")
              .eq(
                "client_id",
                client.client_id
              );

            if (stepsError) {
              throw stepsError;
            }

            const totalSteps =
              projectSteps.length;

            const completedSteps =
              projectSteps.filter(
                (step) =>
                  step.step_status ===
                  "completed"
              ).length;

            const progressPercentage =
              totalSteps === 0
                ? 0
                : Math.round(
                    (completedSteps /
                      totalSteps) *
                      100
                  );

            const allCompleted =
              totalSteps > 0 &&
              projectSteps.every(
                (step) =>
                  step.step_status ===
                  "completed"
              );

            const allPending =
              totalSteps > 0 &&
              projectSteps.every(
                (step) =>
                  step.step_status ===
                  "pending"
              );

            let currentStep =
              "In Progress";

            if (
              allCompleted
            ) {
              currentStep =
                "Completed";
            } else if (
              allPending
            ) {
              currentStep =
                "Not Started Yet";
            }

            const assignedMemberIds =
              [
                ...new Set(
                 projectSteps.flatMap(
  step => step.assigned_member_ids || []
)
                ),
              ];

            let assignedMembers =
              [];

            if (
              assignedMemberIds.length
            ) {
              const {
                data: members,
                error:
                  membersError,
              } = await supabase
                .from(
                  "members"
                )
                .select(
                  "member_id, full_name"
                )
                .in(
                  "member_id",
                  assignedMemberIds
                );

              if (
                membersError
              ) {
                throw membersError;
              }

              assignedMembers =
                members?.map(
                  (
                    member
                  ) =>
                    member.full_name
                      ?.split(
                        " "
                      )
                      .map(
                        (
                          part
                        ) =>
                          part[0]
                      )
                      .join("")
                      .slice(
                        0,
                        2
                      )
                      .toUpperCase()
                ) || [];
            }

            return {
              client_id:
                client.client_id,

              client_name:
                client.client_name,

              event_type:
                client.event_name,


              current_step:
                currentStep,

              progress_percentage:
                progressPercentage,

              assigned_members:
                assignedMembers,
            };
          }
        )
      );

    return res.status(200).json({
      success: true,
      data: dashboardData,
    });
  } catch (error) {
    console.error(
      "Get All Clients Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        error?.message ||
        "Internal Server Error",
    });
  }
};

export const getClientAssets =
  async (req, res) => {
    try {
      const { clientId } =
        req.params;

      const page = Number(
        req.query.page || 1
      );

      const limit = 4;

      const fileCategory =
        req.query.fileCategory;

      const from =
        (page - 1) * limit;

      const to =
        from + limit - 1;

      let query = supabase
        .from("files")
        .select("*", {
          count: "exact",
        })
        .eq(
          "client_id",
          clientId
        );

      if (
        fileCategory &&
        fileCategory !== "all"
      ) {
        query = query.eq(
          "file_category",
          fileCategory
        );
      }

      const {
        data: files,
        error,
        count,
      } = await query
        .order(
          "created_at",
          {
            ascending: false,
          }
        )
        .range(from, to);

      if (error) {
        throw error;
      }

      const filesWithPreview =
        await Promise.all(
          files.map(
            async (file) => {
              const command =
                new GetObjectCommand({
                  Bucket:
                    process.env
                      .R2_BUCKET,
                  Key:
                    file.object_storage_key,
                });

              const previewUrl =
                await getSignedUrl(
                  r2,
                  command,
                  {
                    expiresIn:
                      3600,
                  }
                );

              return {
                ...file,

                preview_url:
                  previewUrl,
              };
            }
          )
        );

      return res.status(200).json({
        success: true,

        data:
          filesWithPreview,

        pagination: {
          page,

          limit,

          total:
            count || 0,

          total_pages:
            Math.ceil(
              (count || 0) /
                limit
            ),

          has_next:
            page * limit <
            (count || 0),
        },
      });
    } catch (error) {
      console.error(
        "Get Client Assets Error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          error?.message ||
          "Internal Server Error",
      });
    }
  };

export const resetClientPassword = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { admin_password } = req.body;
    if (!admin_password) return res.status(400).json({ success: false, message: "Your admin password is required" });

    const { data: admin, error: adminError } = await supabase
      .from("members")
      .select("member_id, password_hash")
      .eq("member_id", req.user.member_id)
      .single();
    if (adminError || !admin) return res.status(401).json({ success: false, message: "Unable to verify administrator" });

    const valid = admin.password_hash?.startsWith("$2")
      ? await bcrypt.compare(admin_password, admin.password_hash)
      : admin_password === admin.password_hash;
    if (!valid) return res.status(401).json({ success: false, message: "Incorrect admin password" });

    const temporaryPassword = crypto.randomBytes(9).toString("base64url");
    const { data: updated, error } = await supabase
      .from("clients")
      .update({ password: await bcrypt.hash(temporaryPassword, 12) })
      .eq("client_id", clientId)
      .select("client_id");
    if (error) throw error;
    if (!updated?.length) return res.status(404).json({ success: false, message: "Client not found" });

    return res.status(200).json({
      success: true,
      message: "Client password reset. Copy it now; it cannot be shown again.",
      temporary_password: temporaryPassword,
    });
  } catch (error) {
    console.error("Reset Client Password Error:", error);
    return res.status(500).json({ success: false, message: "Unable to reset client password" });
  }
};

  export const updateClient =
  async (req, res) => {
    try {
      const { clientId } =
        req.params;

      const {
        client_name,
        event_date,
        event_type,
        event_location,
      } = req.body;


      const {
        data: client,
        error,
      } = await supabase
        .from("clients")
        .update({
          client_name,

          event_date,

          event_name:
            event_type,

          event_location,
        })
        .eq(
          "client_id",
          clientId
        )
        .select()
        .single();

      if (error) {
        throw error;
      }

      return res.status(200).json({
        success: true,
        message:
          "Client updated successfully",
        data: client,
      });
    } catch (error) {
      console.error(
        "Update Client Error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          error?.message ||
          "Internal Server Error",
      });
    }
  };


  export const createMember = async (req, res) => {
  try {
    const { name, role, email, phone, password } = req.body;
    const cleanEmail = String(email || "").trim().toLowerCase();
    if (!name || !cleanEmail || !password) {
      return res.status(400).json({ success: false, message: "Name, email and password are required." });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(cleanEmail)) {
      return res.status(400).json({ success: false, message: "Enter a valid email address." });
    }
    if (String(password).length < 10) {
      return res.status(400).json({ success: false, message: "Password must be at least 10 characters." });
    }
    // Admins can add team members and admins; only a superadmin can add a superadmin.
    const allowedRoles = req.user.role === "superadmin" ? ["team", "admin", "superadmin"] : ["team", "admin"];
    const memberRole = role || "team";
    if (!allowedRoles.includes(memberRole)) {
      return res.status(403).json({ success: false, message: "You cannot create a member with that role." });
    }

    const { data, error } = await supabase
      .from("members")
      .insert({
        full_name: String(name).trim(),
        role: memberRole,
        email: cleanEmail,
        phone_number: phone || null,
        password_hash: await bcrypt.hash(String(password), 12),
      })
      .select("member_id, full_name, email, role, phone_number")
      .single();

    if (error) {
      const duplicate = error.code === "23505";
      return res.status(duplicate ? 409 : 500).json({
        success: false,
        message: duplicate ? "A member with this email already exists." : "Could not create member.",
      });
    }

    return res.status(201).json({ success: true, message: "Member created successfully.", data });
  } catch (err) {
    console.error("Create member error:", err);
    return res.status(500).json({ success: false, message: "Could not create member." });
  }
};
